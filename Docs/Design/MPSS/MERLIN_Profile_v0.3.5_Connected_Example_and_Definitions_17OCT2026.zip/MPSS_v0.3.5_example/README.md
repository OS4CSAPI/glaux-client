# MPSS v0.3.5 connected design example

All entities, identifiers, measurements, dates, actors and operations are synthetic. These JSON bodies illustrate the separately authored OGC-binding proposal, not TRSS or OmniSense payloads. No API is deployed. The example namespace is not published or approved.

Start with 00_manifest.json, 02_station.sml.json and 08_site_deployment.sml.json. Follow native resource links and profile-defined typed reference values. domain_catalogue.json defines every local term and records its source or authored status. Native SensorML and CSAPI field names are not replaced by those terms.

The original v0.3.3 connected case covers model, equipment, sensing, deployment, configuration/control, communications, RFC 7326-informed power relations and service history. The fictional administrative post-service review is a SensorML service Event, NOT an Observation or a condition/health assessment. R20 remains an optional Observation binding for actual measured or method-derived condition findings; no invented thresholds are included. All response files are review artifacts; do not POST them unchanged. Link targets for collections and non-JSON material are illustrative service contracts, not included server implementations.

Quality checks: JSON parsing, local vocabulary coverage, selected references/fragments, and consistency of named output/input/parameter references are checked by the build process. These are editorial checks, not schema conformance or interoperability evidence. The approved working typed power relationships use the MERLIN-authored energy-relationship group: powers, meters, aggregates; the two sample edges use powers only. Power Interfaces, additional battery detail and live metering remain for later decisions. The original v0.3 ZIP and v0.3.1 and v0.3.2 technical baselines remain unchanged. No code to operate hardware is included.

REVISION STATUS: The R08/R12/R16/R20 disposition and its precise edits were approved by the project owner and incorporated as technical working v0.3.2 on 17 October 2026. This is not v0.4, normative source conformance, interoperability evidence, or a deployable service. Earlier sample files 24–27 were withdrawn because their administrative review was incorrectly represented as a CSAPI Observation.

Identifier stability: all provisional /0.3/ URIs intentionally remain unchanged in v0.3.2. This technical revision is not an independently registered semantic namespace; later migration is a separately governed decision.

## Second controlled increment: source identity and mediation (v0.3.3)

The station still has its original physical uniqueId, model reference, integrated probe, mast attachment, and equipment capabilities. Its additional `representation-source` CharacteristicList is an optional **MERLIN-authored** provenance convention, illustrating a hypothetical SAPIENT v2 message sender and translation adapter. The native sender ID deliberately does not appear in `System.uniqueId`, `System.typeOf`, `System.identifiers[]`, or `components[]`, because no evidence establishes physical identity or component equivalence. The adapter uses an example URN, not a newly invented service or endpoint.

The physically connected gateway and its time-scoped access links remain in `08_site_deployment.sml.json` under `gateway-access`; these are not the software adapter. The source spec edition label is a contextual identifier, NOT a claim of SAPIENT conformance, implementation or a verified native payload. No native SAPIENT feed, registration message, source link or producer-side implementation was available in this purely synthetic fixture.

This increment does not change the /0.3/ example vocabulary URI namespace, physical System or Deployment identities, defined power and event behavior, or dynamic API resource records. Structural JSON checks and internal reference checks are editorial, not OGC conformance tests.

## Third approved increment: native Modes and supported products (v0.3.4)

Resource bodies 01–23 are unchanged from v0.3.3, including original station identity, source mediation, configuration, commands, power and history. Supplementary files 28–30 add an independent synthetic sensor with native routine/rapid Modes. No claim is made that the original station, a real SAPIENT sender or any donor hardware supports these invented modes or timing values. Retired files 24–27 are not restored.

Both Modes use existing sensing-function and function-binding groups, shared process parameter/output definitions, and native Settings; the profile explicitly scopes group interpretation to the enclosing Mode. A configured preset is not a report of present mode or readiness. The routine product has an exposed empty stream and an available schema; the rapid product is declared with no exposed stream in this fixture. All four observation-derived empty-stream summaries are null. See MODE_AWARE_MAPPING_CASE.md for exact source roles, expected interpretation and limitations.

The mode-aware rule and product/data distinction were substantively approved before this implementation; no second wording gate applies. No new term, group, code-space or profile-scope URI was added. The glossary/catalogue records clarified interpretation only; prior /0.3/ identifiers remain provisional. Verification is bounded editorial consistency, not a complete source-schema or live-adapter conformance test.

## Fourth approved increment: subjects, lineage preservation and quantity mapping (v0.3.5)

All 26 v0.3.4 resource bodies (01–23 and 28–30) are byte-identical. R11 now explicitly selects native sampling/part subjects where appropriate, retains lightweight subjectRef otherwise, and protects historical context. Donor fusion, association, tracking, correction, recall and resolution meanings remain source-specific rather than becoming a fabricated common lineage model. See R11_SUBJECT_AND_LINEAGE_GUIDANCE.md.

Files 31–33 are independent auxiliary battery-voltage mapping/definition/schema fragments. They convert 12600 mV to 12.6 V and zero to zero, and handle RFC 7577's undetermined code before scaling. The local schema NIL token -9999 means unknown, not a voltage or a universal policy. The single new qualified property term is illustrative only; generic source-terminal-voltage and the original supplies are unchanged. See R17_BATTERY_VOLTAGE_MAPPING_CASE.md.

The manifest identifies auxiliary material separately from the preserved resource list. Prior narrative version labels are historical; its workingRevision now correctly records v0.3.5. Approval covers the bounded edits and verification once. No common lineage resolver, source-adapter code, normative IEEE field mapping, full power specialization or technical profile v0.4 is implied.
