# R17: battery-voltage conversion without invented equipment facts — v0.3.5

**Independent illustrative fixture, not data from the original station, power-a or power-b.** It does not implement SNMP, ingest a native packet or prove RFC/OGC conformance.

Read `31_battery_voltage_mapping_cases.json`, `32_battery_voltage_property.sml.json` and `33_battery_voltage_result_schema.json` in that order. They are auxiliary test/definition fragments, not complete served resources or POST bodies. The source field and its unit/reserved-code meaning are from RFC 7577 (July 2015), §5, `batteryActualVoltage`. Equipment identity, acquisition method and timestamp are deliberately not fabricated.

The new example-only URI ends in `term/rfc7577-battery-actual-voltage`. Native SensorML DerivedProperty carries its local qualification and QUDT Voltage base; SWE Quantity carries the same definition and unit code `V`. This is a selected semantic translation, not an assertion that RFC 7577 or QUDT published our URI. The established generic `supply-terminal-voltage` property and all old resource bodies remain unchanged.

| Native value | Interpretation | Example encoded result |
|---|---|---|
| 12600 mV | Divide by 1000 | 12.6 V |
| 0 mV | Valid zero; not the reserved missing code | 0 V |
| 0xFFFFFFFF (4294967295) | Voltage cannot be determined; handle before division | -9999, declared NIL with reason Unknown |

The -9999 token is chosen only for this result schema. It cannot collide with an ordinary nonnegative converted Unsigned32 value; it is not a physical negative voltage and must be excluded from numerical interpretation. The example uses SWE Common's published `nilValues` form and its published Unknown reason URI. A different integration may choose another properly declared nil representation. Never scale the source sentinel into 4294967.295 V or treat zero as missing by guesswork.

In an actual integration, preserve the correct source-qualified battery identity, observed subject, property, unit, acquisition/context time and any source-specified reference point. Do not infer DC polarity, an additional terminal resource, a battery condition estimate, accuracy or a permissible operating range from the MIB value alone. A generic external-source reading must not be silently relabeled as battery-specific.

Implementation target: selected source-field translation into the applicable native OGC result/property structures and the MPSS interpretation rules. Not the RFC 7577 battery MIB conformance groups. Serving SamplingFeature/Property resources would additionally require the applicable Part 1 classes and encodings; a fixture alone supplies no server conformance. Tests in this release check arithmetic, nil handling, references and preservation—not source-agent or full schema interoperability.

Sources: https://www.rfc-editor.org/rfc/rfc7577.html (§5, batteryActualVoltage); https://docs.ogc.org/is/23-001/23-001.html (§§15.2, 19.2.8); https://docs.ogc.org/is/24-014/24-014.html (§§8.2.16, 9.1.15); https://schemas.opengis.net/sensorML/3.0/json/DerivedProperty.json; https://schemas.opengis.net/sweCommon/3.0/json/Quantity.json; https://qudt.org/vocab/quantitykind/Voltage. All were checked as described in the release evidence record on 17 October 2026.
