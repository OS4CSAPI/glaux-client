# U-INT-01 / R04–R10: native-mode and product-availability design case

**Standing:** owner-approved MERLIN design convention; entirely synthetic example. Not a native SAPIENT/ISA/SOSA/OSUS/IEEE payload, a tested adapter, a current device-state record or a new API. The original files 01–23 are unchanged.

## Read the case

`28_mode_sensor.sml.json` defines a separate physical sensing System. It has one shared parameter (`sampleInterval`, seconds, base limits 10–3600) and two shared output definitions (`airTemperatureRoutine`, `airTemperatureRapid`, both the existing illustrative air-temperature quantity in Cel). Two native Modes carry existing MERLIN groups and native configuration. No top-level configuration selects an active Mode, and no status Observation is invented. Mode uniqueIds are descriptive identifiers, not separate API endpoints.

| Descriptive mode | Preset / allowed interval | Output enabled by its Settings | Data exposure in this fixture |
|---|---|---|---|
| Routine | 120 s / 60–3600 s | airTemperatureRoutine; rapid output disabled | Empty DataStream in 29; schema in 30; no Observations |
| Rapid | 10 s / 10–30 s | airTemperatureRapid; routine output disabled | No corresponding stream is exposed; declaration remains valid |

The values are invented illustration, not donor-mandated performance. Shared quantities are declared once at process level; mode-specific Settings narrow allowed intervals without copying property definitions/units. Each mode's function-binding resolves its owner#id capability inside that Mode and named paths against the containing process. The two mode-qualified function groups have distinct ids; sharing `environmental-measurement` as a function-kind does not identify them as the same group.

## Expected readings and prohibited inferences

A profile-aware client should retain the Mode context while joining the function, shared parameter, output and Settings. It should show the routine product's exposed stream as having no linked observations in this fixture, not pretend that `observedProperties=null` removes the declared air-temperature capability. It should preserve the rapid product without inventing a stream URI, and leave the active Mode and source-specific readiness unreported. The old `10_temperature_stream.json` separately shows recorded historical data with `live=false`; non-live is not unsupported.

In live discovery, failure to find a matching stream may reflect authorization, pagination or filtering; this file does not prescribe unsupported-equipment status from an incomplete search. Listing Modes does not establish their current selection, and listing all process outputs does not establish simultaneous enabled operation. This fixture does not define how multiple independent concurrent mode groups should be merged, a new setModes path grammar or a scheduler.

## Source-to-design mapping and limits

| Source / locator | Source contribution | MERLIN treatment / fidelity boundary |
|---|---|---|
| SensorML 3.0 OGC 23-000 §§8.8.1–8.8.2; Mode.json → DescribedObject.json; AbstractProcess.json modes[] | Mode metadata and Settings; at least two Modes when a list is used | Direct use of native carrier; group scoping/path reading is authored. This does not claim the complete configurable-process conformance class. |
| Settings.json; SWE basicTypes AllowedValues | Native presets, allowed parameter intervals, enabled/disabled outputs | The example instantiates setValues/setConstraints/setStatus; fixture numbers are invented. |
| BSI Flex 335 v2.0:2024-03, completed research memo's R04/R09 discussion and Tables 19,27,33,49 references | Mode-related declarations motivate keeping function/parameters/products together | Semantic design requirement preserved through OGC; no native protobuf conversion or claim that SAPIENT adopts SensorML. |
| ISA Component Requirements 6.0r4 CMPT-L-0072; Phase 2 memo | Enabled command readiness is not general availability | Do not equate ISA ready to DataStream.live or invent a common ready flag. No ISA state field is simulated here. |
| CSAPI Part 2 OGC 23-002 §9.2.2 | Empty-stream observation-derived summaries are null; live indicates live data | 29 preserves nulls and false live; 30 independently describes a possible result schema. No observations are manufactured. |
| OMS3 completed memo, prospective capability versus observations | Capability may precede actual measurements | R10 declaration remains visible; no mandatory ObservingCapability endpoint or blanket OMS conformance. |
| IEEE 1451/TEDS Pass 1A §11 | Exact channel/performance details remain source-gated | No range, uncertainty, calibration or timing values are attributed to IEEE in this case. |

This demonstrates the chosen common representation's internal coherence, not complete donor coverage, data fidelity from an actual native record, or live interoperability. Source-native references can still be retained where deeper information cannot be mapped; no new provenance mechanism is created here.
