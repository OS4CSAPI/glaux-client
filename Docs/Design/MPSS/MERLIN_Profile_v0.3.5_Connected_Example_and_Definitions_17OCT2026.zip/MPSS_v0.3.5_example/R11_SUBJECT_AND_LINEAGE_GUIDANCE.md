# R11: native subjects and source-specific lineage — v0.3.5

**Approved guidance. No new common lineage fields or native adapter.** Existing resource bodies 01–23 and 28–30 are unchanged.

## Subject selection

Use the actual native SamplingFeature route when a source describes a specimen, sampling location, or relevant observed part and independent subject access is useful. Retain its `sampledFeature` relation to the sampled/ultimate feature. In the Part 1 GeoJSON encoding this relation is `properties.sampledFeature@link`; in Part 2 JSON an observation can reference `samplingFeature@id`. A System can itself be the ultimate feature of interest. Do not turn every physical component into a SamplingFeature solely because it has an identifier.

When no separately exposed sampling resource is appropriate, the existing schema-declared `Observation.parameters.subjectRef` can still refine an embedded subject inside the correct owning feature. It must not contradict native sampling semantics or redirect a reading to unrelated equipment. An inaccessible or nonexistent source resource is not repaired by inventing a URL.

The schema's stream-level `featureOfInterest@link`, `samplingFeature@link` and `deployment@link` are shared-context assertions. Preserve separate fixed-subject streams or supported observation-specific sampling references when that context changes. Do not relabel all past records when a battery is replaced. Original files 16–18 describe power-b only; no earlier power-a observations are supplied.

## Donor relation meanings

| Source | Meaning to preserve | Do not silently equate with |
|---|---|---|
| BSI Flex 335 v2.0, §5.5 | Associated detections; in fusion, contributing detections. Association may also have another source-defined role. | A universal derivation relation |
| BSI v2 §6.4.2.19 | Original detection's reference to a derived fused detection | Another report in a track |
| BSI v2 §6.4.2.1–2; §5.5 note | Report identity versus detected-object identity; repeated object reports may form a track | Global physical-object identity or fusion membership |
| ISA Data Model Topics 6.0r2 §§2.2–2.5 | Correction; recall of an erroneous observation; resolution of a valid event; tracks | One generic update, deletion, derivation or equipment-service event |

Preserve source-qualified IDs, actual relation kind/direction, time/context and source edition in a documented source-specific result/parameter when the carrier meaning fits. Otherwise retain accessible native records through applicable existing document/link/result mechanisms and document the unmapped content. Do not assert missing reciprocal links, conflate a node with the observed object or infer entity equivalence from matching names. R15 System provenance does not solve observation lineage.

This is preservation guidance, not demonstrated cross-donor normalization. A common client may display or link native content without understanding every relation. A common lineage convention/resolver remains conditional on source-grounded examples and a separately approved need. No fabricated fused payload is included.

Sources: OGC 23-001 §§14, 19.1.8; OGC 23-002 §9 and published dataStream.json/observation.json; BSI Flex 335 v2.0:2024-03 §5.5, §6.4.2.1–2/19; supplied ISA Data Model Topics 6.0r2 §§2.2–2.5. Full source URLs and implementation boundaries are recorded in the release evidence note.
